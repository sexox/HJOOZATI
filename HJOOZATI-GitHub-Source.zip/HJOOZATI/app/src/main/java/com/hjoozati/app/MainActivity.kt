package com.hjoozati.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.hjoozati.app.data.AppDatabase
import com.hjoozati.app.data.Booking
import com.hjoozati.app.data.BookingDao
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val Ink = Color(0xFF08070D)
private val Panel = Color(0xFF17131F)
private val Panel2 = Color(0xFF21192D)
private val Purple = Color(0xFFB86CFF)
private val PurpleDeep = Color(0xFF7628C7)
private val Gold = Color(0xFFF3B94F)
private val Muted = Color(0xFFAAA2B5)
private val Good = Color(0xFF63D6A2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val dao = AppDatabase.get(this).bookingDao()
        setContent {
            val vm: BookingViewModel = viewModel(factory = BookingViewModel.Factory(dao))
            HjoozatiApp(vm)
        }
    }
}

class BookingViewModel(private val dao: BookingDao) : ViewModel() {
    val bookings = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    var message by mutableStateOf<String?>(null)
        private set

    fun clearMessage() { message = null }

    fun save(booking: Booking) = viewModelScope.launch {
        val conflict = dao.findOverlap(booking.date, booking.startMinutes, booking.endMinutes, booking.id)
        if (conflict != null) {
            message = "هذا الوقت متعارض مع حجز ${conflict.customerName} (${conflict.startTime} - ${conflict.endTime})"
            return@launch
        }
        if (booking.id == 0L) dao.insert(booking) else dao.update(booking)
        message = "تم حفظ الحجز بنجاح"
    }

    fun delete(booking: Booking) = viewModelScope.launch {
        dao.delete(booking)
        message = "تم حذف الحجز"
    }

    fun updateStatus(booking: Booking, status: String) = viewModelScope.launch {
        dao.update(booking.copy(status = status))
    }

    class Factory(private val dao: BookingDao) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = BookingViewModel(dao) as T
    }
}

@Composable
private fun HjoozatiApp(vm: BookingViewModel) {
    val bookings by vm.bookings.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    var editor by remember { mutableStateOf<Booking?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    val today = LocalDate.now().toString()
    val todayBookings = bookings.filter { it.date == today && it.status != "ملغي" }
    val todayIncome = todayBookings.sumOf { it.paid }
    val totalDue = bookings.filter { it.status != "ملغي" }.sumOf { it.remaining }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let { snackbar.showSnackbar(it); vm.clearMessage() }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Gold, background = Ink, surface = Panel,
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            snackbarHost = { SnackbarHost(snackbar) },
            floatingActionButton = {
                FloatingActionButton(onClick = { editor = null; showEditor = true }, containerColor = Gold, contentColor = Ink) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة حجز")
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Purple) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("الحجوزات") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Payments, null) }, label = { Text("الحسابات") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> DashboardScreen(bookings, todayBookings.size, todayIncome, totalDue, Modifier.padding(padding), onAdd = { editor = null; showEditor = true }, onEdit = { editor = it; showEditor = true }, onDelete = vm::delete)
                1 -> BookingsScreen(bookings, Modifier.padding(padding), onEdit = { editor = it; showEditor = true }, onDelete = vm::delete, onStatus = vm::updateStatus)
                else -> FinanceScreen(bookings, Modifier.padding(padding))
            }
            if (showEditor) {
                BookingEditor(initial = editor, onDismiss = { showEditor = false }, onSave = { vm.save(it); showEditor = false })
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    bookings: List<Booking>, todayCount: Int, todayIncome: Long, due: Long, modifier: Modifier,
    onAdd: () -> Unit, onEdit: (Booking) -> Unit, onDelete: (Booking) -> Unit
) {
    val today = LocalDate.now().toString()
    val upcoming = bookings.filter { it.date >= today && it.status != "ملغي" }.take(4)
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 26.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("مرحباً بك", color = Muted, fontSize = 13.sp)
                    Text("حجوزاتي", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("إدارة ملعبك بكل سهولة", color = Gold, fontSize = 12.sp)
                }
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(PurpleDeep, Gold))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.SportsSoccer, null, tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF39204F), Color(0xFF17121F), Color(0xFF30200F)))).border(1.dp, Purple.copy(alpha = .45f), RoundedCornerShape(24.dp)).padding(20.dp)) {
                Column {
                    Text("ملخص اليوم", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("${LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MiniMetric("حجوزات اليوم", todayCount.toString(), Purple)
                        MiniMetric("المقبوض اليوم", money(todayIncome), Gold)
                        MiniMetric("المتبقي", money(due), Good)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الحجوزات القادمة", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("${upcoming.size} مواعيد", color = Gold, fontSize = 12.sp)
            }
        }
        if (upcoming.isEmpty()) item { EmptyState("ماكو حجوزات قادمة", "اضغط + حتى تضيف أول حجز") }
        items(upcoming, key = { it.id }) { BookingCard(it, onEdit, onDelete) }
        item { OutlinedButton(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold), border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = .65f))) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("إضافة حجز جديد") } }
    }
}

@Composable
private fun MiniMetric(label: String, value: String, color: Color) {
    Column {
        Text(label, color = Muted, fontSize = 10.sp)
        Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BookingsScreen(bookings: List<Booking>, modifier: Modifier, onEdit: (Booking) -> Unit, onDelete: (Booking) -> Unit, onStatus: (Booking, String) -> Unit) {
    var filter by remember { mutableStateOf("الكل") }
    val filtered = when (filter) {
        "المؤكدة" -> bookings.filter { it.status == "مؤكد" }
        "بانتظار" -> bookings.filter { it.status == "بانتظار التأكيد" }
        "ملغية" -> bookings.filter { it.status == "ملغي" }
        else -> bookings
    }
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("الحجوزات", fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 25.dp, bottom = 16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("الكل", "المؤكدة", "بانتظار", "ملغية").forEach { label ->
                FilterChip(selected = filter == label, onClick = { filter = label }, label = { Text(label) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleDeep, selectedLabelColor = Color.White))
            }
        }
        LazyColumn(contentPadding = PaddingValues(top = 12.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (filtered.isEmpty()) item { EmptyState("لا توجد حجوزات", "أضف حجزاً جديداً من زر +") }
            items(filtered, key = { it.id }) { booking ->
                Column {
                    BookingCard(booking, onEdit, onDelete)
                    if (booking.status != "ملغي") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onStatus(booking, "بانتظار التأكيد") }) { Text("انتظار", color = Gold) }
                            TextButton(onClick = { onStatus(booking, "مؤكد") }) { Text("تأكيد", color = Good) }
                            TextButton(onClick = { onStatus(booking, "ملغي") }) { Text("إلغاء", color = Color(0xFFFF7777)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BookingCard(booking: Booking, onEdit: (Booking) -> Unit, onDelete: (Booking) -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).border(1.dp, Purple.copy(alpha = .18f), RoundedCornerShape(20.dp)).padding(15.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(booking.customerName, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("${booking.teamOne.ifBlank { "الفريق الأول" }}  ×  ${booking.teamTwo.ifBlank { "الفريق الثاني" }}", color = Muted, fontSize = 12.sp)
            }
            StatusPill(booking.status)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${booking.date} • ${booking.startTime} - ${booking.endTime}", color = Gold, fontSize = 12.sp)
            Text("${money(booking.total)} د.ع", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        if (booking.matchType == "بطولة") Text("${booking.tournamentName} • ${booking.tournamentStage}", color = Purple, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("مدفوع: ${money(booking.paid)}  |  متبقي: ${money(booking.remaining)}", color = Muted, fontSize = 11.sp)
            Row {
                IconButton(onClick = { onEdit(booking) }) { Icon(Icons.Default.Edit, "تعديل", tint = Gold) }
                IconButton(onClick = { onDelete(booking) }) { Icon(Icons.Default.Delete, "حذف", tint = Color(0xFFFF7777)) }
                IconButton(onClick = { openWhatsApp(context, booking) }) { Text("WA", color = Good, fontWeight = FontWeight.Black, fontSize = 13.sp) }
            }
        }
    }
}

@Composable
private fun StatusPill(status: String) {
    val color = when (status) { "مؤكد" -> Good; "ملغي" -> Color(0xFFFF7777); else -> Gold }
    Text(status, color = color, fontSize = 10.sp, modifier = Modifier.clip(CircleShape).background(color.copy(alpha = .12f)).padding(horizontal = 10.dp, vertical = 5.dp))
}

@Composable
private fun FinanceScreen(bookings: List<Booking>, modifier: Modifier) {
    val valid = bookings.filter { it.status != "ملغي" }
    val total = valid.sumOf { it.total }
    val paid = valid.sumOf { it.paid }
    val remaining = valid.sumOf { it.remaining }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("الحسابات", fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 25.dp, bottom = 20.dp))
        FinanceTile("إجمالي قيمة الحجوزات", total, Gold)
        FinanceTile("المبالغ المستلمة", paid, Good)
        FinanceTile("المبالغ المتبقية", remaining, Purple)
        Spacer(Modifier.height(12.dp))
        Text("ملخص الحسابات يعتمد على الحجوزات المسجلة محلياً.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun FinanceTile(title: String, amount: Long, color: Color) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Muted, fontSize = 13.sp)
        Text("${money(amount)} د.ع", color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.CalendarMonth, null, tint = Purple, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun BookingEditor(initial: Booking?, onDismiss: () -> Unit, onSave: (Booking) -> Unit) {
    val today = LocalDate.now().toString()
    var name by remember(initial) { mutableStateOf(initial?.customerName.orEmpty()) }
    var phone by remember(initial) { mutableStateOf(initial?.phone.orEmpty()) }
    var date by remember(initial) { mutableStateOf(initial?.date ?: today) }
    var start by remember(initial) { mutableStateOf(initial?.startTime ?: "19:00") }
    var end by remember(initial) { mutableStateOf(initial?.endTime ?: "20:00") }
    var team1 by remember(initial) { mutableStateOf(initial?.teamOne.orEmpty()) }
    var team2 by remember(initial) { mutableStateOf(initial?.teamTwo.orEmpty()) }
    var price by remember(initial) { mutableStateOf(initial?.pricePerTeam?.toString() ?: "6000") }
    var paid by remember(initial) { mutableStateOf(initial?.paid?.toString() ?: "0") }
    var matchType by remember(initial) { mutableStateOf(initial?.matchType ?: "ودية") }
    var tournament by remember(initial) { mutableStateOf(initial?.tournamentName.orEmpty()) }
    var stage by remember(initial) { mutableStateOf(initial?.tournamentStage ?: "دوري المجموعات") }
    var notes by remember(initial) { mutableStateOf(initial?.notes.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel2,
        title = { Text(if (initial == null) "حجز جديد" else "تعديل الحجز", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item { FormField("اسم الزبون", name, { name = it }) }
                item { FormField("رقم الهاتف", phone, { phone = it }, KeyboardType.Phone) }
                item { FormField("التاريخ (YYYY-MM-DD)", date, { date = it }) }
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { FormField("من (HH:mm)", start, { start = it }) }; Box(Modifier.weight(1f)) { FormField("إلى (HH:mm)", end, { end = it }) } } }
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { FormField("الفريق الأول", team1, { team1 = it }) }; Box(Modifier.weight(1f)) { FormField("الفريق الثاني", team2, { team2 = it }) } } }
                item { FormField("السعر لكل فريق بالدينار", price, { price = it }, KeyboardType.Number) }
                item { FormField("المبلغ المدفوع", paid, { paid = it }, KeyboardType.Number) }
                item { Text("نوع المباراة", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("ودية", "بطولة").forEach { v -> FilterChip(selected = matchType == v, onClick = { matchType = v }, label = { Text(v) }) } } }
                if (matchType == "بطولة") {
                    item { FormField("اسم البطولة", tournament, { tournament = it }) }
                    item { Text("المرحلة", color = Gold, fontSize = 12.sp) }
                    item { Column { listOf("دوري المجموعات", "ربع النهائي", "نصف النهائي", "النهائي").forEach { v -> Row(Modifier.fillMaxWidth().clickable { stage = v }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = stage == v, onClick = { stage = v }, colors = RadioButtonDefaults.colors(selectedColor = Gold)); Text(v, fontSize = 13.sp) } } } }
                }
                item { FormField("ملاحظات", notes, { notes = it }) }
                if (error != null) item { Text(error!!, color = Color(0xFFFF7777), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val startM = parseMinutes(start); val endM = parseMinutes(end)
                val p = price.toLongOrNull(); val pay = paid.toLongOrNull()
                error = when {
                    name.isBlank() -> "اكتب اسم الزبون"
                    phone.isBlank() -> "اكتب رقم الهاتف"
                    runCatching { LocalDate.parse(date) }.isFailure -> "صيغة التاريخ غير صحيحة"
                    startM == null || endM == null || endM <= startM -> "تحقق من وقت البداية والنهاية"
                    p == null || p < 0 || pay == null || pay < 0 -> "تحقق من المبالغ"
                    pay > p * 2 -> "المبلغ المدفوع أكبر من مجموع الحجز"
                    matchType == "بطولة" && tournament.isBlank() -> "اكتب اسم البطولة"
                    else -> null
                }
                if (error == null) onSave(Booking(
                    id = initial?.id ?: 0, customerName = name.trim(), phone = phone.trim(), date = date,
                    startTime = start, endTime = end, startMinutes = startM!!, endMinutes = endM!!,
                    teamOne = team1.trim(), teamTwo = team2.trim(), pricePerTeam = p!!, paid = pay!!,
                    matchType = matchType, tournamentName = if (matchType == "بطولة") tournament.trim() else "",
                    tournamentStage = if (matchType == "بطولة") stage else "", notes = notes.trim(),
                    status = initial?.status ?: "مؤكد", createdAt = initial?.createdAt ?: System.currentTimeMillis()
                ))
            }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = Muted) } }
    )
}

@Composable
private fun FormField(label: String, value: String, onValue: (String) -> Unit, keyboard: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label, fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = keyboard), colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF51465E), focusedLabelColor = Gold,
        cursorColor = Gold, focusedTextColor = Color.White, unfocusedTextColor = Color.White
    ))
}

internal fun parseMinutes(value: String): Int? = runCatching {
    val parts = value.split(":")
    require(parts.size == 2)
    val h = parts[0].toInt(); val m = parts[1].toInt()
    require(h in 0..23 && m in 0..59)
    h * 60 + m
}.getOrNull()

private fun money(value: Long): String = String.format("%,d", value).replace(",", "٬")

private fun openWhatsApp(context: android.content.Context, booking: Booking) {
    val phone = booking.phone.filter { it.isDigit() || it == '+' }.replace("+", "")
    val tournamentLine = if (booking.matchType == "بطولة") "\nالبطولة: ${booking.tournamentName}\nالمرحلة: ${booking.tournamentStage}" else ""
    val message = "تحية طيبة أستاذ ${booking.customerName}\nتم تثبيت حجزك يوم ${booking.date} من الساعة ${booking.startTime} إلى ${booking.endTime}\nالمبلغ: ${money(booking.pricePerTeam)} دينار لكل فريق\nمجموع الفريقين: ${money(booking.total)} دينار\nالمدفوع: ${money(booking.paid)} دينار\nالمتبقي: ${money(booking.remaining)} دينار$tournamentLine"
    val url = "https://wa.me/$phone?text=" + URLEncoder.encode(message, "UTF-8")
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}
